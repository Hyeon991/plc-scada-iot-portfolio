#include "esp_camera.h"
//
#define CAMERA_MODEL_M5STACK_NO_PSRAM

#include <SimpleTimer.h>
SimpleTimer clientloop;

//와이파이 라이브러리
#include <WiFiManager.h>

//mqtt sub pub라이브러리
#include <PubSubClient.h>
#define CharSize 5 //mqtt publishing은 char형만 가능
char getdata[CharSize];

//핀 설정
#define flashlight 4 //보드 내장형 조명(4로 고정됨)

// MQTT Broker
const char *mqtt_broker = "broker.mqtt-dashboard.com";
//publish 토픽명 설정
const char *sendpic = "esp32camict/out/sendpic";
const char *flashlightRespond = "esp32camict/out/flashlightRespond";
const char *esp32camcondition = "esp32camict/out/condition";
//subscribe 토픽명 설정 (in/ 이하 일괄구독)
const char *intopic = "esp32camict/in/#";
const char *mqtt_username = "esp32cam";
const char *mqtt_password = "esp32cam";
const int mqtt_port = 1883;

WiFiClient espClient;
PubSubClient client(espClient);

//
// WARNING!!! Make sure that you have either selected ESP32 Wrover Module,
//            or another board which has PSRAM enabled
//

// Select camera model
//#define CAMERA_MODEL_WROVER_KIT
//#define CAMERA_MODEL_ESP_EYE
//#define CAMERA_MODEL_M5STACK_PSRAM
//#define CAMERA_MODEL_M5STACK_WIDE
#define CAMERA_MODEL_AI_THINKER

#include "camera_pins.h"

void startCameraServer();

void setup() {
  Serial.begin(115200);
  Serial.setDebugOutput(true);
  Serial.println();

  clientloop.setInterval(100, clientloopFunc);
  
  pinMode(flashlight, OUTPUT);

  camera_config_t config;
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer = LEDC_TIMER_0;
  config.pin_d0 = Y2_GPIO_NUM;
  config.pin_d1 = Y3_GPIO_NUM;
  config.pin_d2 = Y4_GPIO_NUM;
  config.pin_d3 = Y5_GPIO_NUM;
  config.pin_d4 = Y6_GPIO_NUM;
  config.pin_d5 = Y7_GPIO_NUM;
  config.pin_d6 = Y8_GPIO_NUM;
  config.pin_d7 = Y9_GPIO_NUM;
  config.pin_xclk = XCLK_GPIO_NUM;
  config.pin_pclk = PCLK_GPIO_NUM;
  config.pin_vsync = VSYNC_GPIO_NUM;
  config.pin_href = HREF_GPIO_NUM;
  config.pin_sscb_sda = SIOD_GPIO_NUM;
  config.pin_sscb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn = PWDN_GPIO_NUM;
  config.pin_reset = RESET_GPIO_NUM;
  config.xclk_freq_hz = 20000000;
  config.pixel_format = PIXFORMAT_JPEG;
  //init with high specs to pre-allocate larger buffers
  if(psramFound()){
    config.frame_size = FRAMESIZE_UXGA;
    config.jpeg_quality = 10;
    config.fb_count = 2;
  } else {
    config.frame_size = FRAMESIZE_SVGA;
    config.jpeg_quality = 12;
    config.fb_count = 1;
  }

#if defined(CAMERA_MODEL_ESP_EYE)
  pinMode(13, INPUT_PULLUP);
  pinMode(14, INPUT_PULLUP);
#endif

  // camera init
  esp_err_t err = esp_camera_init(&config);
  if (err != ESP_OK) {
    Serial.printf("Camera init failed with error 0x%x", err);
    return;
  }

  sensor_t * s = esp_camera_sensor_get();
  //initial sensors are flipped vertically and colors are a bit saturated
  if (s->id.PID == OV3660_PID) {
    s->set_vflip(s, 1);//flip it back
    s->set_brightness(s, 1);//up the blightness just a bit
    s->set_saturation(s, -2);//lower the saturation
  }
  //drop down frame size for higher initial frame rate
  s->set_framesize(s, FRAMESIZE_QVGA);

#if defined(CAMERA_MODEL_M5STACK_WIDE)
  s->set_vflip(s, 1);
  s->set_hmirror(s, 1);
#endif

  WiFi.mode(WIFI_STA); // explicitly set mode, esp defaults to STA+AP
    // it is a good practice to make sure your code sets wifi mode how you want it.
    
    //WiFiManager, Local intialization. Once its business is done, there is no need to keep it around
    WiFiManager wm;
    
    //wm.resetSettings();

    bool res;
    // res = wm.autoConnect(); // auto generated AP name from chipid
     res = wm.autoConnect("esp32_cam_stream"); // anonymous ap
   // res = wm.autoConnect("AutoConnectAP","password"); // password protected ap

    if(!res) {
        Serial.println("Failed to connect");
        ESP.restart();
    } 
    else {
        //if you get here you have connected to the WiFi    
        Serial.println("connected...yeey :)");
    }

  startCameraServer();

  Serial.print("Camera Ready! Use 'http://");
  Serial.print(WiFi.localIP());
  Serial.println("' to connect");

  //mqtt broker 연결
  client.setServer(mqtt_broker, mqtt_port);
  client.setCallback(callback);
  while (!client.connected()) {
     String client_id = "esp32-client-";
     client_id += String(WiFi.macAddress());
     Serial.printf("The client %s connects to the public mqtt broker\n", client_id.c_str());
     if (client.connect(client_id.c_str(), mqtt_username, mqtt_password)) {
         Serial.println("Public broker connected");
     } else {
         Serial.print("failed with state ");
         Serial.print(client.state());
         delay(2000);
     }
 }
    
 client.subscribe(intopic); //셋업 과정의 sub구독
 client.publish(esp32camcondition, "ONLINE");
 
}

//콜백
void callback(char *topic, byte *payload, unsigned int length) {
  
 Serial.print("Message arrived in topic: ");
 Serial.println(topic);
 Serial.print("Message:");
 for (int i = 0; i < length; i++) {
     Serial.print((char) payload[i]);
     getdata[i] = ((char) payload[i]); //배열에 저장
 }
 Serial.println();
 Serial.println("-----------------------");

 if (strcmp(topic, "esp32camict/in/flashlight") == 0)
   {
    if((char)payload[0] == '1')
    {
      digitalWrite(flashlight, HIGH);
      client.publish(flashlightRespond, "Light ON - OK");
    }
    else if((char)payload[0] == '0')
    {
      digitalWrite(flashlight, LOW);
      client.publish(flashlightRespond, "Light OFF - OK");
    }
   }
   /*
   if (strcmp(topic, "esp32camict/in/takepic") == 0)
   {
     digitalWrite(flashlight, HIGH);
     take_picture();
     digitalWrite(flashlight, LOW);
   }
   */

}

void reconnect() {
  while (!client.connected()) {
    Serial.println("Attempting MQTT connection...");
    if (client.connect("ESP32_clientID")) {
      Serial.println("connected");
      // Once connected, publish an announcement...
      //client.publish(outtopic, "Nodemcu connected to MQTT");
      // ... and resubscribe 재연결시 재구독
      client.subscribe(intopic);
      client.publish(esp32camcondition, "ONLINE");

    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 5 seconds");
      // Wait 5 seconds before retrying
      //delay(5000);
    }
  }
}

void loop() {
  clientloop.run();
}

void clientloopFunc()
{
  if(!client.connected())
   {
    reconnect();
   }
  client.loop();
  client.publish(esp32camcondition, "ONLINE");
}
/*
void take_picture() {
  digitalWrite(flashlight, HIGH);
  camera_fb_t * fb = NULL;
  fb = esp_camera_fb_get();
  if (!fb) {
    Serial.println("Camera capture failed");
    return;
  }
  if (MQTT_MAX_PACKET_SIZE == 128) {
    //SLOW MODE (increase MQTT_MAX_PACKET_SIZE)
    client.publish_P(sendpic, fb->buf, fb->len, false);
  }
  else {
    //FAST MODE (increase MQTT_MAX_PACKET_SIZE)
    client.publish(sendpic, fb->buf, fb->len, false);
    Serial.println(fb->len);
  }
  Serial.println("CLIC");
  esp_camera_fb_return(fb);
  digitalWrite(flashlight, LOW);
}
*/
