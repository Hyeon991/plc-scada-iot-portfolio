#include <SimpleTimer.h>
SimpleTimer dhtpublish;
//SimpleTimer gpspublish;
SimpleTimer clientloop;
SimpleTimer ultrasonic;
SimpleTimer pir;
SimpleTimer emergency;
SimpleTimer lightcontrol;
SimpleTimer leding;

int emergency_status = 0;

int leding_mode = 1;

//LCD 라이브러리
#include <LiquidCrystal_I2C.h>
#include <Wire.h>

LiquidCrystal_I2C lcd(0x27,20,4);

//WiFi
#include <WiFiManager.h>

//시간 동기화
const char* ntpServer = "kr.pool.ntp.org";

const long gmtOffset_sec = 32400; //GMT+9
const int daylightOffset_sec = 0; //섬머타임 적용시 3600(1시간 빠르게 함). 우리나라는 0

int Year;
int Month;
int Day;
int Hour;
int Minute;
int Sec;

struct tm timeinfo;

void readLocalTime()
{
  if(!getLocalTime(&timeinfo))
  {
    Serial.println("Failed to obtain time");
    return;
  }
  //Serial.println(&timeinfo, "%A, %B %d %Y %H:%M:%S");
  
  Year = ((timeinfo.tm_year)+1900);
  Month = ((timeinfo.tm_mon)+1);
  Day = (timeinfo.tm_mday);
  Hour = (timeinfo.tm_hour);
  Minute = (timeinfo.tm_min);
  Sec = (timeinfo.tm_sec);

  lcd.setCursor(0,0);
  lcd.print("TIMO V5.1.        ");
  
  lcd.setCursor(0,1);
  lcd.print("DT:");
  lcd.print(Month);
  lcd.print("/");
  lcd.print(Day);
  lcd.print(" ");
  lcd.print(Hour);
  lcd.print(":");
  lcd.print(Minute);
  lcd.print(":");
  lcd.print(Sec);
  lcd.print("  ");

  if(emergency_status == 1)
  {
    lcd.setCursor(0,2);
    lcd.print("Status:EMERGENCY");
    Serial.println(emergency_status);
  }
  else
  {
    lcd.setCursor(0,2);
    lcd.print("Status:NORMAL       ");
    Serial.println(emergency_status);
  }
}

//google api키로 위치값 들고오기
/*
#include <WifiLocation.h>
const char* googleApiKey = "AIzaSyDlRwD0O2MnD0C0-1C6XQ59ni5MyAoWyvM";
WifiLocation location (googleApiKey);
*/
void setClock () {
    configTime (9*3600, 0, "pool.ntp.org", "time.nist.gov");

    Serial.print ("Waiting for NTP time sync: ");
    time_t now = time (nullptr);
    while (now < 8 * 3600 * 2) {
        //delay (500);
        Serial.print (".");
        now = time (nullptr);
    }
    struct tm timeinfo;
    gmtime_r (&now, &timeinfo);
    Serial.print ("\n");
    Serial.print ("Current time: ");
    Serial.print (asctime (&timeinfo));
}

//mqtt sub pub라이브러리
#include <PubSubClient.h>
#define CharSize 5 //mqtt publishing은 char형만 가능
char getdata[CharSize];

// MQTT Broker
const char *mqtt_broker = "broker.mqtt-dashboard.com";
//publish 토픽명 설정
const char *tempout = "esp32mainict/out/dht_t";
const char *humiout = "esp32mainict/out/dht_h";
const char *latout = "esp32mainict/out/lat";
const char *lonout = "esp32mainict/out/lon";
const char *flashout = "esp32mainict/out/flash";
const char *emergencymsg = "esp32mainict/out/emergencymsg";
const char *pirflashmodeRespond = "esp32mainict/out/pirflashmodeRespond";
const char *esp32maincondition = "esp32mainict/out/condition";
const char *ledstatus = "esp32mainict/out/ledstatus";
const char *lightstatus = "esp32mainict/out/lightstatus";
//subscribe 토픽명 설정 (in/ 이하 일괄구독)
const char *intopic = "esp32mainict/in/#";
const char *mqtt_username = "esp32main";
const char *mqtt_password = "esp32main";

const int mqtt_port = 1883;

WiFiClient espClient;
PubSubClient client(espClient);

//온습도
  #include "DHT.h"
DHT dht(15, DHT11);

//초음파
long distance;
#define trigpin 19
#define echopin 18

//핀설정
//RGB
//#define R 25
//#define G 32
//#define B 33
//릴레이
#define ledmodule 14
#define lightmodule 12
//적외선
#define pirpin 23
//조난발생
#define emergencypin 13
//부저
//#define buzzpin 15
//불꽃감지
//#define flamepin 5

//밀리스제어
unsigned long leding_onmil;
unsigned long leding_on_interval = 4000;
unsigned long leding_offmil;
unsigned long leding_off_interval = 1000;

unsigned long pir_nextmil;
unsigned long pir_interval = 5000;
int pirflashmode = 0; //근접 카메라 플래시 사용유무
/*
unsigned long light_nextmil;
unsigned long light_onmil = 250;
unsigned long light_offmil = 250;
int light_stat = 0;
*/

void setup() {
  Serial.begin(115200);
  lcd.begin();
  lcd.backlight();
  /*
  ledcSetup(4, 5000, 8);
  ledcSetup(5, 5000, 8);
  ledcSetup(6, 5000, 8);
  ledcAttachPin(R, 4);
  ledcAttachPin(G, 5);
  ledcAttachPin(B, 6);
  */

  pinMode(ledmodule, OUTPUT);
  pinMode(lightmodule, OUTPUT);
  digitalWrite(ledmodule, LOW);
  digitalWrite(lightmodule, LOW);

  pinMode(pirpin, INPUT);

  pinMode(emergencypin, INPUT_PULLUP);
  /*  
  pinMode(R, OUTPUT);
  pinMode(G, OUTPUT);
  pinMode(B, OUTPUT);
  */

  //pinMode(buzzpin, OUTPUT);

  //pinMode(flamepin, INPUT);

  dhtpublish.setInterval(3000, dhtpublishFunc);
  //gpspublish.setInterval(300000, gpspublishFunc);
  clientloop.setInterval(100, clientloopFunc);
  ultrasonic.setInterval(500, ultrasonicFunc);
  pir.setInterval(500, pirFunc);
  emergency.setInterval(100, emergencyFunc);
  //lightcontrol.setInterval(1, lightcontrolFunc);
  leding.setInterval(1000, ledingFunc);

  lcd.setCursor(0,0);
  lcd.print("Connecting WiFi~");

  WiFi.mode(WIFI_STA); // explicitly set mode, esp defaults to STA+AP
    // it is a good practice to make sure your code sets wifi mode how you want it.
    
    //WiFiManager, Local intialization. Once its business is done, there is no need to keep it around
    WiFiManager wm;

    //wm.resetSettings();

    bool res;
    // res = wm.autoConnect(); // auto generated AP name from chipid
     res = wm.autoConnect("TIMO v5.1._main"); // anonymous ap
   // res = wm.autoConnect("AutoConnectAP","password"); // password protected ap

    if(!res) {
        Serial.println("Failed to connect");
        //ESP.restart();
    } 
    else {
        //if you get here you have connected to the WiFi    
        Serial.println("connected...yeey :)");
    }

    //mqtt broker 연결
  client.setServer(mqtt_broker, mqtt_port);
  client.setCallback(callback);
  while (!client.connected()) {
      String client_id = "esp32-client-";
      client_id += String(WiFi.macAddress());
      Serial.printf("The client %s connects to the public mqtt broker\n", client_id.c_str());
      if (client.connect(client_id.c_str(), mqtt_username, mqtt_password)) {
          Serial.println("Public broker connected");
      } else {
          Serial.print("failed with state ");
          Serial.print(client.state());
          delay(1000);
      }   
    }
   client.subscribe(intopic); //셋업 과정의 sub구독
   client.publish(esp32maincondition, "ONLINE");

   //온습도 1회 publish
   int temp;
   char tempmsg[5];
   int humi;
   char humimsg[5];
  
   temp = dht.readTemperature();
   humi = dht.readHumidity();

   String tempstring = String(temp);
   tempstring.toCharArray(tempmsg, sizeof(tempmsg));
   String humistring = String(humi);
   humistring.toCharArray(humimsg, sizeof(humimsg));

   client.publish(tempout, tempmsg);
   client.publish(humiout, humimsg);

   //light_nextmil = millis();

   //구글 api키 위치값과 1회 publish
   setClock();
   
   /*location_t loc = location.getGeoFromWiFi();
   
   Serial.println("Location request data");
   Serial.println(location.getSurroundingWiFiJson()+"\n");
   Serial.println ("Location: " + String (loc.lat, 10) + "," + String (loc.lon, 10));
   Serial.println ("Accuracy: " + String (loc.accuracy));
   Serial.println ("Result: " + location.wlStatusStr (location.getStatus ()));
   
   float flat;
   char latmsg[15];
   float flon;
   char lonmsg[15];
  
   String lat_string = String (loc.lat, 15);
   lat_string.toCharArray(latmsg, sizeof(lat_string));
   String lon_string = String (loc.lon, 15);
   lon_string.toCharArray(lonmsg, sizeof(lon_string));
   client.publish(latout, latmsg);
   client.publish(lonout, lonmsg);
   */

   leding_onmil = millis() + leding_on_interval;
}

//콜백
void callback(char *topic, byte *payload, unsigned int length) {
  
 Serial.print("Message arrived in topic: ");
 Serial.println(topic);
 Serial.print("Message:");
 for (int i = 0; i < length; i++) {
     Serial.print((char) payload[i]);
     getdata[i] = ((char) payload[i]); //배열에 저장
 }
 Serial.println();
 Serial.println("-----------------------");

 if (strcmp(topic, "esp32mainict/in/emergencystop") == 0)
   {
    if((char)payload[0] == '0')
    {
      emergency_status = 0;
    }
   }

 if (strcmp(topic, "esp32mainict/in/pirflashmode") == 0)
   {
    if((char)payload[0] == '0')
    {
      pirflashmode = 0;
      client.publish(pirflashmodeRespond, "PIR Light Mode OFF - OK");
    }
    else if((char)payload[0] == '1')
    {
      pirflashmode = 1;
      client.publish(pirflashmodeRespond, "PIR Light Mode ON - OK");
    }
   }

   if (strcmp(topic, "esp32mainict/in/ledmodule") == 0)
   {
    if((char)payload[0] == '0')
    {
      digitalWrite(ledmodule, LOW);
      if(digitalRead(ledmodule) == LOW)
      {
        client.publish(ledstatus, "OFF");
      }
    }
    else if((char)payload[0] == '1')
    {
      digitalWrite(ledmodule, HIGH);
      if(digitalRead(ledmodule) == HIGH)
      {
        client.publish(ledstatus, "ON"); 
      }
    }
   }

   if(strcmp(topic, "esp32mainict/in/lightmodule") == 0)
   {
    if((char)payload[0] == '0')
    
    {
      digitalWrite(lightmodule, LOW);
      if(digitalRead(lightmodule) == LOW)
      {
        client.publish(lightstatus, "OFF");
      }
    }
    else if((char)payload[0] == '1')
    {
      digitalWrite(lightmodule, HIGH);
      if(digitalRead(lightmodule) == HIGH)
      {
        client.publish(lightstatus, "ON");
      }
    }
   }

   if(strcmp(topic, "esp32mainict/in/ledingmode") == 0)
   {
    if((char)payload[0] == '1')
    {
      leding_mode = 1;
    }
    else if((char)payload[0] == '0')
    {
      leding_mode = 0;
    }
   }
 
}

void reconnect() {
  while (!client.connected()) {
    Serial.println("Attempting MQTT connection...");
    if (client.connect("ESP32_clientID")) {
      Serial.println("connected");
      // Once connected, publish an announcement...
      //client.publish(outtopic, "Nodemcu connected to MQTT");
      // ... and resubscribe 재연결시 재구독
      client.subscribe(intopic);
      client.publish(esp32maincondition, "ONLINE");
      
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 5 seconds");
      // Wait 5 seconds before retrying
      //delay(5000);
    }
  }
}

void loop() {
  readLocalTime();
  clientloop.run();
  dhtpublish.run();
  //gpspublish.run();
  ultrasonic.run();
  pir.run();
  emergency.run();

  if(leding_mode == 1)
  {
    leding.run();
  }

  if(emergency_status == 1)
  {
    lightcontrol.run();
  }

  //delay(1000);
}

void clientloopFunc()
{
  if(!client.connected())
   {
    reconnect();
   }
  client.loop();
  client.publish(esp32maincondition, "ONLINE");
}

void ledingFunc()
{
  if(digitalRead(ledmodule) == HIGH && millis() >= leding_offmil)
  {
    leding_onmil = millis() + leding_on_interval;
    digitalWrite(ledmodule, LOW);
    
    digitalWrite(lightmodule, LOW);
    client.publish(ledstatus, "ON");
    client.publish(lightstatus, "ON");
    Serial.println(leding_onmil);
    Serial.println(digitalRead(ledmodule));
    Serial.println(digitalRead(lightmodule));
  }
  else if(digitalRead(ledmodule) == LOW && millis() >= leding_onmil)
  {
    leding_offmil = millis() + leding_off_interval;
    digitalWrite(ledmodule, HIGH);
    digitalWrite(lightmodule, HIGH);
    client.publish(ledstatus, "OFF");
    client.publish(lightstatus, "OFF");
    Serial.println(leding_offmil);
    Serial.println(digitalRead(ledmodule));
    Serial.println(digitalRead(lightmodule));
  }
}

/*void lightcontrolFunc()
{
  if(light_stat == 0 && millis() >= light_nextmil)
    {
      setColor(0, 255, 255);
      light_nextmil = millis() + light_onmil;
      light_stat = 1;
    }
    else if(light_stat == 1 && millis() >= light_nextmil)
    {
      setColor(255, 255, 255);
      light_nextmil = millis() + light_offmil;
      light_stat = 0;
    }
}*/

void dhtpublishFunc()
{
  //온습도값 변수방과 publish를 위한 Char배열 설정
  int temp;
  char tempmsg[5];
  int humi;
  char humimsg[5];
  
  temp = dht.readTemperature();
  humi = dht.readHumidity();

  String tempstring = String(temp);
  tempstring.toCharArray(tempmsg, sizeof(tempmsg));
  String humistring = String(humi);
  humistring.toCharArray(humimsg, sizeof(humimsg));

  client.publish(tempout, tempmsg);
  client.publish(humiout, humimsg);
}


/*void gpspublishFunc()
{
  location_t loc = location.getGeoFromWiFi();
  
  float flat;
  char latmsg[15];
  float flon;
  char lonmsg[15];
  
  String lat_string = String (loc.lat, 15);
  lat_string.toCharArray(latmsg, sizeof(lat_string));
  String lon_string = String (loc.lon, 15);
  lon_string.toCharArray(lonmsg, sizeof(lon_string));
  client.publish(latout, latmsg);
  client.publish(lonout, lonmsg);
}
*/
void ultrasonicFunc()
{
  long duration;
  digitalWrite(trigpin, LOW);
  delay(2);
  digitalWrite(trigpin, HIGH);
  delay(10);
  digitalWrite(trigpin, LOW);
  duration = pulseIn(echopin, HIGH);
  distance = duration * 17 / 1000;
  Serial.print("distance:");
  Serial.println(distance);
}

void pirFunc()
{
  //Serial.print("pir:");
  //Serial.println(digitalRead(pirpin));
  if(pirflashmode == 1)
  {
    if(digitalRead(pirpin) == 1 && 50 > distance)
    {
     client.publish(flashout, "ON");
     pir_nextmil = millis() + pir_interval;
    }
    else if(millis() >= pir_nextmil && digitalRead(pirpin) == 0)
    {
     client.publish(flashout, "OFF");
    }
  }
}

void emergencyFunc()
{
  //Serial.print("emerpin:");
  //Serial.println(digitalRead(emergencypin));
  //Serial.print("flamepin:");
  //Serial.println(digitalRead(flamepin));
  if(digitalRead(emergencypin) == 0 && 50 > distance)
  {
   client.publish(emergencymsg, "EMERGENCY");
   emergency_status = 1;
  }
  /*
  else if(digitalRead(flamepin) == 1)
  {
   client.publish(emergencymsg, "FLAME");
   emergency_status = 1;
  }
  */
}
