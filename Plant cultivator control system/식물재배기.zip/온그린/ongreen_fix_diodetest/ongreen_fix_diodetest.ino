//핀 설정
#define airfan 32 //순환팬
#define heatfan 33 //히터팬
#define pump 25 //펌프
#define led 26 //식물 LED

//심플타이머
#include <SimpleTimer.h>
SimpleTimer dhtread;
SimpleTimer heatfaning;
SimpleTimer leding;
SimpleTimer pumping;

unsigned long pump_nextmil;
unsigned long onmil = 60000;

//LCD 라이브러리
#include <LiquidCrystal_I2C.h>
#include <Wire.h>

LiquidCrystal_I2C lcd(0x27,16,2);

//온습도
#include "DHT.h"
DHT dht(23, DHT11);

int temp;
int humi;

//WiFiManager
#include <WiFiManager.h>

//시간 동기화
const char* ntpServer = "kr.pool.ntp.org";

const long gmtOffset_sec = 32400; //GMT+9
const int daylightOffset_sec = 0; //섬머타임 적용시 3600(1시간 빠르게 함). 대한민국 = 0

int Year;
int Month;
int Day;
int Hour;
int Minute;
int Sec;

struct tm timeinfo;

void readLocalTime()
{
  if(!getLocalTime(&timeinfo))
  {
    Serial.println("Failed to obtain time");
    return;
  }
  Serial.println(&timeinfo, "%A, %B %d %Y %H:%M:%S");
  
  Year = ((timeinfo.tm_year)+1900);
  Month = ((timeinfo.tm_mon)+1);
  Day = (timeinfo.tm_mday);
  Hour = (timeinfo.tm_hour);
  Minute = (timeinfo.tm_min);
  Sec = (timeinfo.tm_sec);
  
  lcd.setCursor(0,1);
  lcd.print("DT:");
  lcd.print(Month);
  lcd.print("/");
  lcd.print(Day);
  lcd.print(" ");
  lcd.print(Hour);
  lcd.print(":");
  lcd.print(Minute);
  lcd.print(":");
  lcd.print(Sec);
  lcd.print("  ");
}

//히터팬
unsigned long heatfan_p_time;
int tempset = 20;
int tempgap = 2;

void setup() {
  Serial.begin(115200);
  
  dht.begin();
  lcd.begin();
  lcd.backlight();
  
  dhtread.setInterval(3000, dhtreadFunc);
  heatfaning.setInterval(3000, heatfaningFunc);
  leding.setInterval(1000, ledingFunc);
  pumping.setInterval(1000, pumpingFunc);
  
  pinMode(airfan, OUTPUT);
  pinMode(pump, OUTPUT);
  pinMode(heatfan, OUTPUT);
  pinMode(led, OUTPUT);

  digitalWrite(airfan, LOW);
  digitalWrite(pump, LOW);
  digitalWrite(heatfan, LOW);
  digitalWrite(led, LOW);
  
  lcd.setCursor(0,0);
  lcd.print("Connecting WiFi~");
  
  //WiFi
  WiFi.mode(WIFI_STA); // 모드를 명시적으로 설정. ESP의 기본값은 STA+AP 모드.
    // 코드에서 원하는 대로 Wi-Fi 모드를 확실하게 설정해 두는 것이 좋음.
    
    WiFiManager wm; // WiFiManager 지역(로컬) 초기화. 작업 완료 후 메모리에 계속 유지할 필요가 없음.

    // wm.resetSettings(); // 와이파이 설정 리셋시 사용
    bool res;
    // res = wm.autoConnect(); // 칩 ID 기반으로 자동 생성된 AP 이름
     res = wm.autoConnect("OnGreen"); // anonymous ap
   // res = wm.autoConnect("AutoConnectAP","password"); // 비밀번호로 보호된 AP

    if(!res) {
        Serial.println("Failed to connect");
        // ESP.restart();
    } 
    else {
        //도달시 WIFI 연결됨
        Serial.println("connected :)");
    }
    
    //시간
    configTime(gmtOffset_sec, daylightOffset_sec, ntpServer);
    readLocalTime();
    
}

void loop() {
  readLocalTime(); //시간
  dhtread.run(); //온습도
  heatfaning.run(); //히터팬
  leding.run(); //LED+환기팬
  pumping.run();
}

//led
void ledingFunc()
{
  if(Hour >= 6 && Hour < 21)
  {
    digitalWrite(led, HIGH);
    digitalWrite(airfan, HIGH);
  }
  else
  {
    digitalWrite(led, LOW);
    digitalWrite(airfan, LOW);
  }
}

void pumpingFunc()
{ 
  if(Hour == 4 && Minute == 0 && Sec == 0)
  {
    digitalWrite(pump, HIGH);
    pump_nextmil = millis() + onmil;
  }
  else if(Hour == 8 && Minute == 0 && Sec == 0)
  {
    digitalWrite(pump, HIGH);
    pump_nextmil = millis() + onmil;
  }
  else if(Hour == 12 && Minute == 0 && Sec == 0)
  {
    digitalWrite(pump, HIGH);
    pump_nextmil = millis() + onmil;
  }
  else if(Hour == 16 && Minute == 0 && Sec == 0)
  {
    digitalWrite(pump, HIGH);
    pump_nextmil = millis() + onmil;
  }
  else if(Hour == 20 && Minute == 0 && Sec == 0)
  {
    digitalWrite(pump, HIGH);
    pump_nextmil = millis() + onmil;
  }
  else if(Hour == 24 && Minute == 0 && Sec == 0)
  {
    digitalWrite(pump, HIGH);
    pump_nextmil = millis() + onmil;
  }

  //정지
  if(millis() >= pump_nextmil && digitalRead(pump) == HIGH)
  {
    digitalWrite(pump, LOW);
  }
}

void heatfaningFunc()
{
  if(temp < tempset)
  {
    digitalWrite(heatfan, HIGH);
  }
  else if(temp >= tempset+tempgap)
  {
    digitalWrite(heatfan, LOW);
  }
}

void dhtreadFunc()
{
  temp = dht.readTemperature();
  humi = dht.readHumidity();
  lcd.setCursor(0,0);
  lcd.print("T:");
  lcd.print(temp);
  lcd.print(" / ");
  lcd.print("H:");
  lcd.print(humi);
  lcd.print("     ");
}
