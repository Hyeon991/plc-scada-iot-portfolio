
//#include <SoftwareSerial.h>
//SoftwareSerial Serial1 (2,3);


//LCD
#include <LiquidCrystal_I2C.h>
#include <Wire.h>

LiquidCrystal_I2C lcd(0x27,20,4);

//"온"
byte newChar1[8] = {
        B01110,
        B10001,
        B01110,
        B00100,
        B11111,
        B00000,
        B10000,
        B11111
};

//"도"
byte newChar2[8] = {
        B11111,
        B10000,
        B10000,
        B11111,
        B00100,
        B00100,
        B00100,
        B11111
};

//"습"
byte newChar3[8] = {
        B00100,
        B01010,
        B10001,
        B11111,
        B10001,
        B11111,
        B10001,
        B11111
};

//º
byte newChar4[8] = {
        B00111,
        B00101,
        B00111,
        B00000,
        B00000,
        B00000,
        B00000,
        B00000
};

//먼
byte newChar5[8] = {
        B11101,
        B10101,
        B10111,
        B11101,
        B00001,
        B01000,
        B01000,
        B01111
};

//지
byte newChar6[8] = {
        B00001,
        B11101,
        B01001,
        B01001,
        B10101,
        B10101,
        B00001,
        B00001
};

//수
byte newChar7[8] = {
        B00100,
        B01010,
        B10001,
        B00000,
        B11111,
        B00100,
        B00100,
        B00100
};

//ppm
byte newChar8[8] = {
        B00000,
        B11011,
        B11011,
        B10010,
        B00000,
        B01010,
        B10101,
        B10101
};


//온습도
#include <DHT.h>
#include <DHT_U.h>
#define DHTPIN 4 //온습도 8번 사용
#define DHTTYPE DHT11
DHT dht(DHTPIN, DHTTYPE);

//PH
#define SensorPin A0            //pH meter Analog output to Arduino Analog Input 0
#define Offset 0.00            //deviation compensate
#define LED 13 //led사용??
#define samplingInterval 20
#define printInterval 800
#define ArrayLenth  40    //times of collection
int pHArray[ArrayLenth];   //Store the average value of the sensor feedback
int pHArrayIndex=0;
float ph = digitalRead(A0);

//Co2
#include <cm1106_i2c.h>

CM1106_I2C cm1106_i2c;

#define CM1107

//방수형 온도계
#include <DS18B20.h>

DS18B20 ds(6);

//EC센서
#include "DFRobot_EC.h"
#include <EEPROM.h>

#define EC_PIN A1
float voltage,ecValue,temperature = 25;
DFRobot_EC ec;

//먼지센서
#define no_dust 0.35

// 아두이노 - 미세 먼지 센서 연결
int dustout=A2;
int v_led=3; //*미세먼지!! 디지털 핀 사용***************

// 센서로 읽은 값 변수 선언
float vo_value=0;

// 센서로 읽은 값을 전압으로 측정 변수
float sensor_voltage=0;

// 실제 미세 먼지 밀도 변수
float dust_density=0;

//핀번호 설정
#define led 9
#define light 10
#define fan 11
#define pump 12

void setup() {

  pinMode(led, OUTPUT);
  pinMode(light, OUTPUT);
  pinMode(fan, OUTPUT);
  pinMode(pump, OUTPUT);
  
  digitalWrite(led, HIGH);
  digitalWrite(light, HIGH);
  digitalWrite(fan, HIGH);
  digitalWrite(pump, HIGH);
  
  Serial.begin(9600);
  Serial1.begin(9600);
  
  lcd.init();
  lcd.backlight();

  lcd.begin(20, 4);
  lcd.createChar(0, newChar1);
  lcd.createChar(1, newChar2);
  lcd.createChar(2, newChar3);
  lcd.createChar(3, newChar4);
  lcd.createChar(4, newChar5);
  lcd.createChar(5, newChar6);
  lcd.createChar(6, newChar7);
  lcd.createChar(7, newChar8);
  
  dht.begin();

  cm1106_i2c.begin();
  cm1106_i2c.read_serial_number();
  cm1106_i2c.check_sw_version();

  ec.begin();

  pinMode(v_led,OUTPUT); // 적외선 led 출력으로 설정

}

void loop() {

  if(Serial1.available())
  Serial.write(Serial1.read());
  if(Serial.available())
  Serial1.write(Serial.read());

  uint8_t ret = cm1106_i2c.measure_result();
    
  float h = dht.readHumidity();
  float t = dht.readTemperature();

  static unsigned long samplingTime = millis();
  static unsigned long printTime = millis();
  static float pHValue,voltage;

  lcd.setCursor(0,0);
  lcd.write(byte(0));
  lcd.write(byte(1));
  lcd.print(":");
  lcd.print(t);
  lcd.write(byte(3));
  lcd.print("C");
  lcd.setCursor(11,0);
  lcd.write(byte(2));
  lcd.write(byte(1));
  lcd.print(":");
  lcd.print(h);
  lcd.print("%");
  lcd.setCursor(0,2);
  lcd.print("PH:");
  lcd.print(pHValue,2);
  lcd.setCursor(8,2);
  lcd.print("EC:");
  lcd.print(ecValue,2);
  lcd.print("ms/cm");
  lcd.setCursor(0,1);
  lcd.write(byte(6));
  lcd.write(byte(0));
  lcd.print(":");
  lcd.print(ds.getTempC());
  lcd.write(byte(3));
  lcd.print("C");
  lcd.setCursor(0,3);
  lcd.print("Co2:");
  lcd.print(cm1106_i2c.co2);
  lcd.write(byte(7));
  lcd.setCursor(9,3);
  lcd.write(byte(4));
  lcd.write(byte(5));
  lcd.print(":");
  lcd.print(dust_density);
  lcd.print("ug");

  
  Serial1.print(t);
  Serial1.print(",");
  Serial1.print(h);
  Serial1.print(",");
  Serial1.println(ds.getTempC());
  Serial1.print(",");
  Serial1.println(pHValue,2);
  Serial1.print(",");
  Serial1.println(ecValue,2);
  Serial1.print(",");
  Serial1.println(cm1106_i2c.co2);
  Serial1.print(",");
  Serial1.println(dust_density);
  Serial1.print(",");

  delay(500);

  if(Serial1.available())
  {
    char data = Serial1.read();
    Serial.write(data);

    //조명
    if(data == 'a')
    {
      digitalWrite(light, LOW);
    }
    
    if(data == 'b')
    {
      digitalWrite(light, HIGH);
    }

    //식물 LED
    if(data == 'c')
    {
      digitalWrite(led, LOW);
    }
    
    if(data == 'd')
    {
      digitalWrite(led, HIGH);
    }

    //공기 순환
    if(data == 'e')
    {
      digitalWrite(fan, LOW);
    }

    if(data == 'f')
    {
      digitalWrite(fan, HIGH);
    }

    //양액 분사
    if(data == 'g')
    {
      digitalWrite(pump, LOW);
    }

    if(data == 'h')
    {
      digitalWrite(pump, HIGH);
    }
  }

  
  

  //Co2
  if (ret == 0) {
    Serial.println(cm1106_i2c.co2);


#if defined(CM1107)
    if (cm1106_i2c.status & (1 << CM1106_I2C_STATUS_CM1107_PREHEATING)) {
      
    } else {
      
    }

    if (cm1106_i2c.status & (1 << CM1106_I2C_STATUS_CM1107_OPERATING_NORMAL)) {
      
    } else {
      
    }

    if (cm1106_i2c.status & (1 << CM1106_I2C_STATUS_CM1107_OVER_MEASUREMENT_RANGE)) {
      
    } else {
      
    }

    if (cm1106_i2c.status & (1 << CM1106_I2C_STATUS_CM1107_LESS_THAN_MEASUREMENT_RANGE)) {
      
    } else {
      
    }

    if (cm1106_i2c.status & (1 << CM1106_I2C_STATUS_CM1107_CALIBRATED)) {
      
    } else {
      
    }

    if (cm1106_i2c.status & (1 << CM1106_I2C_STATUS_CM1107_LIGHT_AGING)) {
      
    } else {
      
    }

    if (cm1106_i2c.status & (1 << CM1106_I2C_STATUS_CM1107_DRIFT)) {
      
    } else {
      
    }

    
#else
    switch (cm1106_i2c.status) {
      case CM1106_I2C_STATUS_PREHEATING: {
          
          break;
        }
      case CM1106_I2C_STATUS_NORMAL_OPERATION: {
          
          break;
        }
      case CM1106_I2C_STATUS_OPERATING_TROUBLE: {
          
          break;
        }
      case CM1106_I2C_STATUS_OUT_OF_FS: {
          
          break;
        }
      case CM1106_I2C_STATUS_NON_CALIBRATED: {
          
          break;
        }
    }
#endif
  }


  //온습도
  if (isnan(t) || isnan(h)) {
    //값 읽기 실패시 시리얼 모니터 출력
    Serial.println("Failed to read from DHT");
  } else {
    //온도, 습도 표시 시리얼 모니터 출력
    Serial.print("온도: "); 
    Serial.print(t);
    Serial.println("ºC");
    Serial.print("습도: "); 
    Serial.print(h);
    Serial.println("%\t");
  }

  

  //ph
  if(millis()-samplingTime > samplingInterval)
  {
      pHArray[pHArrayIndex++]=analogRead(SensorPin);
      if(pHArrayIndex==ArrayLenth)pHArrayIndex=0;
      voltage = avergearray(pHArray, ArrayLenth)*5.0/1024;
      pHValue = 3.5*voltage+Offset;
      samplingTime=millis();
  }
  if(millis() - printTime > printInterval)   //Every 800 milliseconds, print a numerical, convert the state of the LED indicator
  {
    Serial.print("Voltage:");
        Serial.print(voltage,2);
        Serial.print("    pH value: ");
    Serial.println(pHValue,2);
        digitalWrite(LED,digitalRead(LED)^1);
        printTime=millis();
  }

//ec센서
static unsigned long timepoint = millis();
    if(millis()-timepoint>1000U)  //time interval: 1s
    {
      timepoint = millis();
      voltage = analogRead(EC_PIN)/1024.0*5000;  // read the voltage
      temperature = ds.getTempC();  // read your temperature sensor to execute temperature compensation
      ecValue =  ec.readEC(voltage,temperature);  // convert voltage to EC with temperature compensation
      Serial.print("temperature:");
      Serial.print(temperature,1);
      Serial.print("^C  EC:");
      Serial.print(ecValue,2);
      Serial.println("ms/cm");
    }
    ec.calibration(voltage,temperature);  // calibration process by Serail CMD

     // 미세 먼지 센서 동작
 digitalWrite(v_led,LOW); // 적외선 LED ON
 delayMicroseconds(280); // 280us동안 딜레이
 vo_value=analogRead(dustout); // 데이터를 읽음
 delayMicroseconds(40); // 320us - 280us
 digitalWrite(v_led,HIGH); // 적외선 LED OFF
 delayMicroseconds(9680); // 10ms(주기) -320us(펄스 폭) 한 값

 sensor_voltage=get_voltage(vo_value);
 dust_density=get_dust_density(sensor_voltage);

  Serial.print("value = ");
  Serial.println(vo_value);
  Serial.print("Voltage = ");
  Serial.print(sensor_voltage);
  Serial.println(" [V]");
  Serial.print("Dust Density = ");
  Serial.print(dust_density);
  Serial.println(" [ug/m^3]");
  
  delay(100);
    
}//loop end
//ph
double avergearray(int* arr, int number){
  int i;
  int max,min;
  double avg;
  long amount=0;
  if(number<=0){
    Serial.println("Error number for the array to avraging!/n");
    return 0;
  }
  if(number<5){   //less than 5, calculated directly statistics
    for(i=0;i<number;i++){
      amount+=arr[i];
    }
    avg = amount/number;
    return avg;
  }else{
    if(arr[0]<arr[1]){
      min = arr[0];max=arr[1];
    }
    else{
      min=arr[1];max=arr[0];
    }
    for(i=2;i<number;i++){
      if(arr[i]<min){
        amount+=min;        //arr<min
        min=arr[i];
      }else {
        if(arr[i]>max){
          amount+=max;    //arr>max
          max=arr[i];
        }else{
          amount+=arr[i]; //min<=arr<=max
        }
      }//if
    }//for
    avg = (double)amount/(number-2);
  }//if
  return avg;
  
}

//미세먼지
float get_voltage(float value)
{
 // 아날로그 값을 전압 값으로 바꿈
 float V= value * 5.0 / 1024; 
 return V;
}

float get_dust_density(float voltage)
{
 // 데이터 시트에 있는 미세 먼지 농도(ug) 공식 기준
 float dust=(voltage-no_dust) / 0.005;
 return dust;
}
