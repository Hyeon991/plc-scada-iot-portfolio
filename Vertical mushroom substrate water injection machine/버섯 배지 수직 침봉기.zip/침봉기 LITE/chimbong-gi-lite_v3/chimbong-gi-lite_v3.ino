

//LCD화면 라이브러리
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27,20,4);

//X 스테이터스 지정 (초기값 0)
int x_status = 0;
//프리 센서방 지정
char pre_sensor;
//스위치문에 사용할 sw방 지정
int sw = 0;
//밀리스 제어를 위한 방들 지정(unsigned long)
unsigned long Count = 0;
unsigned long nowmil = 0;
int main_count = 0; (초기값 0)
unsigned long onmil_main = 60000;//제어 시간


//x = 수평, y = 수직
int cylinder_y_water=2; //수직실린더 하강 + 관수 릴레이

int cylinder_x_f_btn_relay=3; //수평 실린더 전진 버튼 릴레이
int cylinder_x_b_btn_relay=4; //수평 실린더 후진 버튼 릴레이

int cylinder_x_f_sensor=8; //수평 실린더 전진 마그네틱 센서
int cylinder_x_b_sensor=9; //수평 실린더 후진 마그네틱 센서

void setup() {
  //LCD 셋업
  lcd.init();
  lcd.backlight();
  
  Serial.begin(9600);

  //입력핀 설정
  pinMode(cylinder_x_f_sensor, INPUT_PULLUP); //센서값 입력
  pinMode(cylinder_x_b_sensor, INPUT_PULLUP); //센서값 입력
  //출력핀 설정
  pinMode(cylinder_y_water, OUTPUT); //침봉+관수 릴레이
  pinMode(cylinder_x_f_btn_relay, OUTPUT); //버튼 릴레이
  pinMode(cylinder_x_b_btn_relay, OUTPUT); //버튼 릴레이
 
  int cylinder_x_f_sensor_val = digitalRead(cylinder_x_f_sensor);
  int cylinder_x_b_sensor_val = digitalRead(cylinder_x_b_sensor);

  if(cylinder_x_f_sensor_val == LOW)
  {
    pre_sensor = 'F';
  }
  else if(cylinder_x_b_sensor_val == LOW)
  {
    pre_sensor = 'B';
  }

  digitalWrite(cylinder_y_water, HIGH);
  digitalWrite(cylinder_x_f_btn_relay, LOW);
  digitalWrite(cylinder_x_b_btn_relay, LOW);
  
}

void loop() {
  /*/////by Shin
  unsigned long now_ms = millis();

   int cylinder_x_f_sensor_val = HIGH;
   int cylinder_x_b_sensor_val = HIGH;
   
  //cylinder_x_f_sensor 읽기
  {
    static unsigned long  prev_ms = 0;
    if (0 == prev_ms) prev_ms = now_ms;
    if (now_ms - prev_ms >= 700) {
      if (digitalRead(cylinder_x_f_sensor) == LOW) {
        prev_ms = now_ms;
        cylinder_x_f_sensor_val = LOW;
      }
    }
  }

  //cylinder_x_b_sensor 읽기
  {
    static unsigned long  prev_ms = 0;
    if (0 == prev_ms) prev_ms = now_ms;
    if (now_ms - prev_ms >= 700) {
      if (digitalRead(cylinder_x_b_sensor) == LOW) {
        prev_ms = now_ms;
        cylinder_x_b_sensor_val = LOW;
      }
    }
  }
  /////
  */
  
  int cylinder_x_f_sensor_val = digitalRead(cylinder_x_f_sensor);
  int cylinder_x_b_sensor_val = digitalRead(cylinder_x_b_sensor);

  Serial.print(x_status);
  Serial.print("(");
  Serial.print(pre_sensor);
  Serial.print("/");
  Serial.print(cylinder_x_f_sensor_val);
  Serial.print(",");
  Serial.print(cylinder_x_b_sensor_val);
  Serial.println(")");
  
  lcd.setCursor(0,0);
  lcd.print("[DosiFarm]");
  lcd.setCursor(0,1);
  lcd.print("Counts:");
  lcd.print(Count);
  lcd.setCursor(0,2);
  lcd.print("Status:");
  lcd.print("Waiting..");

  if(x_status == 1)
  {
    sw = 1;
  }
  else if(x_status == 0 || x_status == 2)
  {
    sw = 2;
  }
  
  
  switch(sw)
  {
    case 1:

     Serial.println("Start-sw1");

     digitalWrite(cylinder_x_f_btn_relay, HIGH); //수평 실린더 후진 버튼 릴레이 OFF
     digitalWrite(cylinder_x_b_btn_relay, HIGH); //수평 실린더 전진 버튼 릴레이 OFF

     lcd.setCursor(0,0);
     lcd.print("[DosiFarm]");
     lcd.setCursor(0,1);
     lcd.print("Counts:");
     lcd.print(Count);
     lcd.setCursor(0,2);
     lcd.print("Status:");
     lcd.print("Watering-");

     delay(500);
     
     digitalWrite(cylinder_y_water, LOW); //수직 실린더 하강 + 침수

     //delay(30000);
     
     if(main_count == 0)
     {
      nowmil = millis();
      main_count = 1;
     }
     
      if(millis() >= nowmil+onmil_main)
      {
       digitalWrite(cylinder_y_water, HIGH); //수직 실린더 상승 + 밸브 잠금

       Count = Count + 4;

       lcd.setCursor(0,0);
       lcd.print("[
       DosiFarm]");
       lcd.setCursor(0,1);
       lcd.print("Counts:");
       lcd.print(Count);
       lcd.setCursor(0,2);
       lcd.print("Status:");
       lcd.print("Watering-");

       delay(500);

       digitalWrite(cylinder_x_f_btn_relay, LOW);
       digitalWrite(cylinder_x_b_btn_relay, LOW);

          if(cylinder_x_f_sensor_val == HIGH && cylinder_x_b_sensor_val == HIGH)
          {
           if(pre_sensor = 'A')
           {
            pre_sensor = 'B';
           }
           else if(pre_sensor = 'B')
           {
            pre_sensor = 'A';
           }
           x_status = 2;
          }
          else if(cylinder_x_f_sensor_val == LOW)
          {
           pre_sensor = 'F';
           x_status = 2;
          }
          else if(cylinder_x_b_sensor_val == LOW)
          {
           pre_sensor = 'B';
           x_status = 2;
          }
          
          main_count = 0;
       }
     
        Serial.println("End-sw1");
     
        break;

    case 2:

    Serial.println("Start-sw2");
    //delay(1000);
    
    if(cylinder_x_f_sensor_val == LOW && pre_sensor != 'F')
    {
     x_status = 1;
    }
    else if(cylinder_x_b_sensor_val == LOW && pre_sensor != 'B')
    {
     x_status = 1;
    }
    else if(cylinder_x_f_sensor_val == HIGH && cylinder_x_b_sensor_val == HIGH)
    {
     x_status = 2;
    }

    Serial.println("End-sw2");
    
     break;
  }
}
