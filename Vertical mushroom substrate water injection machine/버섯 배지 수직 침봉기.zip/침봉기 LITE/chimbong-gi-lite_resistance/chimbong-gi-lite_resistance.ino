

#include <LiquidCrystal_I2C.h>

LiquidCrystal_I2C lcd(0x27,20,4);

int x_status = 0;
char pre_sensor;
int sw = 0;
unsigned int count = 0;


//x = 수평, y = 수직
int cylinder_y_water=2; //수직실린더 하강 + 관수 릴레이

int cylinder_x_f_btn_relay=3; //수평 실린더 전진 버튼 릴레이
int cylinder_x_b_btn_relay=4; //수평 실린더 후진 버튼 릴레이

int cylinder_x_f_sensor=8; //수평 실린더 전진 마그네틱 센서
int cylinder_x_b_sensor=9; //수평 실린더 후진 마그네틱 센서

void setup() {
  lcd.init();
  lcd.backlight();
  
  Serial.begin(9600);
  
  pinMode(cylinder_x_f_sensor, INPUT_PULLUP);
  pinMode(cylinder_x_b_sensor, INPUT_PULLUP);

  pinMode(cylinder_y_water, OUTPUT);

  pinMode(cylinder_x_f_btn_relay, OUTPUT);
  pinMode(cylinder_x_b_btn_relay, OUTPUT);

  int cylinder_x_f_sensor_val = digitalRead(cylinder_x_f_sensor);
  int cylinder_x_b_sensor_val = digitalRead(cylinder_x_b_sensor);

  if(cylinder_x_f_sensor_val == LOW)
  {
    pre_sensor = 'F';
  }
  else if(cylinder_x_b_sensor_val == LOW)
  {
    pre_sensor = 'B';
  }

  digitalWrite(cylinder_y_water, HIGH);
  digitalWrite(cylinder_x_f_btn_relay, LOW);
  digitalWrite(cylinder_x_b_btn_relay, LOW);
  
}

void loop() {
  /*/////by Shin
  unsigned long now_ms = millis();

   int cylinder_x_f_sensor_val = HIGH;
   int cylinder_x_b_sensor_val = HIGH;
   
  //cylinder_x_f_sensor 읽기
  {
    static unsigned long  prev_ms = 0;
    if (0 == prev_ms) prev_ms = now_ms;
    if (now_ms - prev_ms >= 700) {
      if (digitalRead(cylinder_x_f_sensor) == LOW) {
        prev_ms = now_ms;
        cylinder_x_f_sensor_val = LOW;
      }
    }
  }

  //cylinder_x_b_sensor 읽기
  {
    static unsigned long  prev_ms = 0;
    if (0 == prev_ms) prev_ms = now_ms;
    if (now_ms - prev_ms >= 700) {
      if (digitalRead(cylinder_x_b_sensor) == LOW) {
        prev_ms = now_ms;
        cylinder_x_b_sensor_val = LOW;
      }
    }
  }
  /////
  */
  
  //int Val = analogRead(A0)/17;
  int Val = map(analogRead(A0), 0, 1024, 0, 60);
  unsigned int TimeVal = Val*1000;
  int cylinder_x_f_sensor_val = digitalRead(cylinder_x_f_sensor);
  int cylinder_x_b_sensor_val = digitalRead(cylinder_x_b_sensor);

 /*if(Val>10)
 {
  lcd.init();
 }*/
  Serial.print(x_status);
  Serial.print("(");
  Serial.print(pre_sensor);
  Serial.print("/");
  Serial.print(cylinder_x_f_sensor_val);
  Serial.print(",");
  Serial.print(cylinder_x_b_sensor_val);
  Serial.println(")");

  lcd.setCursor(0,0);
  lcd.print("[FarmIn]");
  lcd.setCursor(0,1);
  lcd.print("TimeSet:");
  lcd.print(Val);
  lcd.print("sec ");
  lcd.setCursor(0,2);
  lcd.print("Counts:");
  lcd.print(count);
  lcd.setCursor(0,3);
  lcd.print("Status:");
  lcd.print("Waiting..");

  if(x_status == 1)
  {
    sw = 1;
  }
  else if(x_status == 0 || x_status == 2)
  {
    sw = 2;
  }
  
  
  switch(sw)
  {
    case 1:

    Serial.println("Start-sw1");

    if(cylinder_x_f_sensor_val == LOW)
     {
       pre_sensor = 'F';
       x_status = 2;
     }
     
     else if(cylinder_x_b_sensor_val == LOW)
     {
       pre_sensor = 'B';
       x_status = 2;
     }

     digitalWrite(cylinder_x_f_btn_relay, HIGH); //수평 실린더 후진 버튼 릴레이 OFF
     digitalWrite(cylinder_x_b_btn_relay, HIGH); //수평 실린더 전진 버튼 릴레이 OFF

     lcd.setCursor(0,0);
     lcd.print("[FarmIn]");
     lcd.setCursor(0,1);
     lcd.print("TimeSet:");
     lcd.print(Val);
     lcd.print("sec ");
     lcd.setCursor(0,2);
     lcd.print("Counts:");
     lcd.print(count);
     lcd.setCursor(0,3);
     lcd.print("Status:");
     lcd.print("Watering-");

     delay(1500);
     
     digitalWrite(cylinder_y_water, LOW); //수직 실린더 하강 + 침수

     delay(TimeVal);
     
     digitalWrite(cylinder_y_water, HIGH); //수직 실린더 상승 + 밸브 잠금

     count = count + 4;

     lcd.setCursor(0,0);
     lcd.print("[FarmIn]");
     lcd.setCursor(0,1);
     lcd.print("TimeSet:");
     lcd.print(Val);
     lcd.print("sec ");
     lcd.setCursor(0,2);
     lcd.print("Counts:");
     lcd.print(count);
     lcd.setCursor(0,3);
     lcd.print("Status:");
     lcd.print("Watering-");

     delay(1500);

     digitalWrite(cylinder_x_f_btn_relay, LOW);
     digitalWrite(cylinder_x_b_btn_relay, LOW);

     if(cylinder_x_f_sensor_val == HIGH && cylinder_x_b_sensor_val == HIGH)
     {
      if(pre_sensor = 'A')
      {
        pre_sensor = 'B';
      }
      else if(pre_sensor = 'B')
      {
        pre_sensor = 'A';
      }
      x_status = 2;
     }
     
     Serial.println("End-sw1");
     
     break;

    case 2:

    Serial.println("Start-sw2");
    //delay(1000);
    
    if(cylinder_x_f_sensor_val == LOW && pre_sensor != 'F')
    {
     x_status = 1;
    }
    else if(cylinder_x_b_sensor_val == LOW && pre_sensor != 'B')
    {
     x_status = 1;
    }
    else if(cylinder_x_f_sensor_val == HIGH && cylinder_x_b_sensor_val == HIGH)
    {
     x_status = 2;
    }

    Serial.println("End-sw2");
    
     break;
  }
}
