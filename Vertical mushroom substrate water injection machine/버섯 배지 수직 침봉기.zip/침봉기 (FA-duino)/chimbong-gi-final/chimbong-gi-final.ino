#include <SimpleModbusRtu_mega2560.h>
uint16_t au16data[16];
uint8_t au8data[10];
char x_status=0;
char pre_sensor;


//x = 수평, y = 수직
int cylinder_x_f=38; //수평 실린더 전진 릴레이
int cylinder_x_b=39; //수평 실린더 후진 릴레이
int cylinder_y_water=40; //수직실린더 하강 + 관수 릴레이

int cylinder_x_f_btn_relay=41; //수평 실린더 전진 버튼 릴레이
int cylinder_x_b_btn_relay=42; //수평 실린더 후진 버튼 릴레이

int cylinder_x_f_sensor=22; //수평 실린더 전진 마그네틱 센서
int cylinder_x_b_sensor=23; //수평 실린더 후진 마그네틱 센서
int cylinder_y_up_sensor=24; //수직 실린더 상승 마그네틱 센서
int cylinder_y_down_sensor=25; //수직 실린더 하강 마그네틱 센서

int cylinder_x_f_sensor_val = digitalRead(cylinder_x_f_sensor);
int cylinder_x_b_sensor_val = digitalRead(cylinder_x_b_sensor);

void setup() {
  Serial.begin(57600);
  
  pinMode(cylinder_x_f_sensor, INPUT);
  pinMode(cylinder_x_b_sensor, INPUT);
  pinMode(cylinder_y_up_sensor, INPUT);
  pinMode(cylinder_y_down_sensor, INPUT);
  pinMode(26, INPUT);
  
  pinMode(cylinder_x_f, OUTPUT);
  pinMode(cylinder_x_b, OUTPUT);
  pinMode(cylinder_y_water, OUTPUT);
  
  pinMode(cylinder_x_f_btn_relay, OUTPUT);
  pinMode(cylinder_x_b_btn_relay, OUTPUT);
  
  usart1init(57600); // 9600, 19200, 38400, 57600, Serial channel1
  startSimpleModbus(1,au16data, au8data); // slave address, register, coil

  if(cylinder_x_f_sensor_val == HIGH)
  {
    pre_sensor = 'F'; 
  }
  else if(cylinder_x_b_sensor_val == HIGH)
  {
    pre_sensor = 'B';
  }

  digitalWrite(cylinder_x_f_btn_relay, HIGH);
  digitalWrite(cylinder_x_b_btn_relay, HIGH);
  
}

void loop() {
  wdt_reset();  // 와치독을 리셋시켜요~!

  bitWrite(au8data[1], 0, digitalRead(cylinder_x_f_sensor)); //00009
  bitWrite(au8data[1], 1, digitalRead(cylinder_x_b_sensor)); //00010
  bitWrite(au8data[1], 2, digitalRead(cylinder_y_up_sensor)); //00011
  bitWrite(au8data[1], 3, digitalRead(cylinder_y_down_sensor)); //00012
  
  int count=0;

  int stop_btn = bitRead(au8data[0], 3);
  int stop_btn_2 = digitalRead(26);
  int reset_btn = bitRead(au8data[0], 4);

  int cylinder_x_f_sensor_val = digitalRead(cylinder_x_f_sensor);
  int cylinder_x_b_sensor_val = digitalRead(cylinder_x_b_sensor);

  int sw = 0;

  if(x_status == 1)
  {
    sw = 1;
  }
  else if(x_status == 0 || x_status == 2)
  {
    sw = 2;
    au16data[6] = 0xB300; //대
     au16data[7] = 0xAE30; //기
     au16data[8] = 0xC911; //중
     au16data[9] = 0x002E; //.
     au16data[10] = 0x002E; //.
     au16data[11] = 0x002E; //.
     au16data[12] = 0x0000;
  }

  if(bitRead(au8data[0], 0) == HIGH) //HMI 수동조작 화면의 전진 버튼
  {
    if(stop_btn == HIGH || stop_btn_2 == HIGH)
    {
      digitalWrite(cylinder_x_f, LOW);
    }
    else
    {
      digitalWrite(cylinder_x_f, HIGH);
    }
  }
  else
  {
    digitalWrite(cylinder_x_f, LOW);
  }

  if(bitRead(au8data[0], 1) == HIGH) //HMI 수동조작 화면의 후진 버튼
  {
    if(stop_btn == HIGH || stop_btn_2 == HIGH)
    {
      digitalWrite(cylinder_x_b, LOW);
    }
    else
    {
      digitalWrite(cylinder_x_b, HIGH);
    }
  }
  else
  {
    digitalWrite(cylinder_x_b, LOW);
  }

  if(bitRead(au8data[0], 2) == HIGH)// HMI 수동조작의 침봉/복귀 버튼
  {
    if(stop_btn == HIGH || stop_btn_2 == HIGH)
    {
      digitalWrite(cylinder_y_water, LOW);
    }
    else
    {
      digitalWrite(cylinder_y_water, HIGH);
    }
  }
  else
  {
    digitalWrite(cylinder_y_water, LOW);
  }

  if(stop_btn == HIGH || stop_btn_2 == HIGH) //토글 전원 버튼이 따로 없었어서 푸시 버튼 하나에 신호선을 연결하여 신호를 받으면 정지하도록 했습니다.
  {
    digitalWrite(cylinder_x_f, LOW);
    digitalWrite(cylinder_x_b, LOW);
    digitalWrite(cylinder_y_water, LOW);
    digitalWrite(cylinder_x_f_btn_relay, LOW);
    digitalWrite(cylinder_x_b_btn_relay, LOW);
     au16data[6] = 0xC791; //작
     au16data[7] = 0xB3D9; //동
     au16data[8] = 0xC815; //정
     au16data[9] = 0xC9C0; //지
     au16data[10] = 0x0000;
  }
  else
  {
    digitalWrite(cylinder_x_f_btn_relay, HIGH);
    digitalWrite(cylinder_x_b_btn_relay, HIGH);
  }    
  if(reset_btn == HIGH)
  {
    au16data[0] = 0;
  }
  Serial.println(reset_btn);

  
  
  switch(sw)
  {
    case 1:

     digitalWrite(cylinder_x_f_btn_relay, LOW); //수평 실린더 후진 버튼 릴레이 OFF
     digitalWrite(cylinder_x_b_btn_relay, LOW); //수평 실린더 전진 버튼 릴레이 OFF

     delay(1500);
     
     digitalWrite(cylinder_y_water, HIGH); //수직 실린더 하강 + 침수
       
     au16data[6] = 0xCE68; //침
     au16data[7] = 0xBD09; //봉
     au16data[8] = 0xC911; //중
     au16data[9] = 0x002E; //.
     au16data[10] = 0x002E; //.
     au16data[11] = 0x002E; //.
     au16data[12] = 0x0000;

     delay(2500);
     bitWrite(au8data[1], 2, digitalRead(cylinder_y_up_sensor)); //00011
     bitWrite(au8data[1], 3, digitalRead(cylinder_y_down_sensor)); //00012

     delay(12000);
     
     digitalWrite(cylinder_y_water, LOW); //수직 실린더 상승 + 밸브 잠금

     au16data[0] = au16data[0] + 4;

     delay(2500);
     bitWrite(au8data[1], 2, digitalRead(cylinder_y_up_sensor)); //00011
     bitWrite(au8data[1], 3, digitalRead(cylinder_y_down_sensor)); //00012

     digitalWrite(cylinder_x_f_btn_relay, HIGH);
     digitalWrite(cylinder_x_b_btn_relay, HIGH);

     if(cylinder_x_f_sensor_val == HIGH)
     {
       pre_sensor = 'F';
       x_status = 2;
     }
     else if(cylinder_x_b_sensor_val == HIGH)
     {
       pre_sensor = 'B';
       x_status = 2;
     }
     break;

    case 2:
    if(cylinder_x_f_sensor_val == HIGH && pre_sensor != 'F')
    {
     x_status = 1;
    }
    else if(cylinder_x_b_sensor_val == HIGH && pre_sensor != 'B')
    {
     x_status = 1;
    }
     break;
  }
}
